$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/features/CreateArticle.feature");
formatter.feature({
  "name": "Create article",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Create article successful with data",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "test"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Article with all empty fields should not be created",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "",
        "",
        "",
        ""
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user is waiting 3 seconds",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userWaits(int)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "error_message": "com.bblog.tests.atfexception.ATFException: User is not on page contained {editor}, but on page {https://candidatex:qa-is-cool@qa-task.backbasecloud.com/#/article/-ql4nc8}\r\n\tat com.bblog.tests.utils.WebDriverWaiter.waitForUrlContains(WebDriverWaiter.java:47)\r\n\tat com.bblog.tests.actions.CommonActions.waitForPageLoaded(CommonActions.java:92)\r\n\tat com.bblog.tests.steps.CommonSteps.ensureThatUserIsOnPage(CommonSteps.java:32)\r\n\tat ✽.ensure that user is on NewArticlePage(src/test/resources/features/CreateArticle.feature:29)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "ensure that article has not been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasNotBeenCreated()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "ensure that user has not any articles created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.ensureThatUserHasntAnyCreatedArticlesBefore()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded0.png");
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/test/resources/features/DeleteArticle.feature");
formatter.feature({
  "name": "Delete article",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Delete created article from container block",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "delete article from container block",
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.deleteArticleFromContainerBlock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user has not any articles created",
  "keyword": "Then "
});
formatter.match({
  "location": "ArticleSteps.ensureThatUserHasntAnyCreatedArticlesBefore()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Delete created article from article actions block",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "delete article from article action block",
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.deleteArticleFromArticleActionBlock()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user has not any articles created",
  "keyword": "Then "
});
formatter.match({
  "location": "ArticleSteps.ensureThatUserHasntAnyCreatedArticlesBefore()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Delete not user article",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    },
    {
      "name": "@RemovePreviousArticleFromAnotherUser"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logout",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userLogout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on MainPage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim1",
        "bcxtim1@bcxtim1.bcxtim1",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to created article link",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.navigateToCreatedArticleLink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user couldn\u0027t remove article",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.userCouldntRemoveArticle()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.uri("src/test/resources/features/UpdateArticle.feature");
formatter.feature({
  "name": "update Article",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update Article from container block",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to created article link",
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.navigateToCreatedArticleLink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to editArticleFromContainer",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on EditArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user updates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title1",
        "about1",
        "article1",
        "tag1"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userUpdatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been updated",
  "keyword": "Then "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update Article from article actions block",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to created article link",
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.navigateToCreatedArticleLink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to editArticleFromActions",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on EditArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user updates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title1",
        "about1",
        "article1",
        "tag1"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userUpdatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been updated",
  "keyword": "Then "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update Article with empty fields",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to created article link",
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.navigateToCreatedArticleLink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to editArticleFromActions",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on EditArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user updates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "",
        "",
        "",
        ""
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userUpdatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on EditArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "error_message": "com.bblog.tests.atfexception.ATFException: User is not on page contained {editor}, but on page {https://candidatex:qa-is-cool@qa-task.backbasecloud.com/#/article/title-c9qstm}\r\n\tat com.bblog.tests.utils.WebDriverWaiter.waitForUrlContains(WebDriverWaiter.java:47)\r\n\tat com.bblog.tests.actions.CommonActions.waitForPageLoaded(CommonActions.java:92)\r\n\tat com.bblog.tests.steps.CommonSteps.ensureThatUserIsOnPage(CommonSteps.java:32)\r\n\tat ✽.ensure that user is on EditArticlePage(src/test/resources/features/UpdateArticle.feature:66)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "ensure that article has not been updated",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasNotBeenCreatedUpdated()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded1.png");
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.background({
  "name": "Login as user with valid credentials",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "Given "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim",
        "bcxtim@bcxtim.bcxtim",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Update not user article",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@RemoveArticle"
    },
    {
      "name": "@Run"
    },
    {
      "name": "@RemovePreviousArticleFromAnotherUser"
    }
  ]
});
formatter.step({
  "name": "user clicks to newArticleLink",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on NewArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user creates a new article with following data:",
  "rows": [
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    },
    {
      "cells": [
        "title",
        "about",
        "article",
        "tag"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "ArticleSteps.userCreatesArticleWithFollowingData(Article)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that article has been created",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.articleHasBeenCreatedUpdated(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user logout",
  "keyword": "When "
});
formatter.match({
  "location": "CommonSteps.userLogout()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user opens application page",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userOpensApplicationPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on MainPage",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user clicks to signInLink",
  "keyword": "And "
});
formatter.match({
  "location": "CommonSteps.userClicksToElementFromPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "login as a user",
  "rows": [
    {
      "cells": [
        "username",
        "email",
        "password"
      ]
    },
    {
      "cells": [
        "bcxtim1",
        "bcxtim1@bcxtim1.bcxtim1",
        "13123974"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.loginAsUser(User)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "navigate to created article link",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.navigateToCreatedArticleLink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "ensure that user is on ArticlePage",
  "keyword": "Then "
});
formatter.match({
  "location": "CommonSteps.ensureThatUserIsOnPage(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user couldn\u0027t edit article",
  "keyword": "And "
});
formatter.match({
  "location": "ArticleSteps.userCouldntEditArticle()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});